# UD4-Multicontenedor_base
TE02 - proyecto base

Éste es un proyecto base del que podéis partir para el desarrollo de la TE02. Podéis modificarlo tanto como necesitéis y consideréis para cumplir con los requisitos del enunciado.

*Propuesta de mejora:* para el servicio de Apache, ¿podríamos utilizar un contenedor más específico y evitar el de Ubuntu?
